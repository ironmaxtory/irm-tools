
const configuration = {
  sidebar: [{
    id: 1,
    title: 'Auto Reload',
    icon: 'icon-auto-reload',
    link: '#/autoreload',
    active: true,
  }]
};



export default configuration;
