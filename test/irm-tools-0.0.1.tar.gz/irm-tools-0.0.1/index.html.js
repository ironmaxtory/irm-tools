var tplEjs = require('./index.html.ejs');


var config = {
};


module.exports = tplEjs(config);
